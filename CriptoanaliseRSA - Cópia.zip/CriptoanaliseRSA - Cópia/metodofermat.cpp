#include <iostream>
#include <cmath>
#include "criptoanalise.hpp"
#include <chrono>
#include <limits>
#include <gmp.h>

using namespace std;
using namespace std::chrono;

int main() {
    //mpz_class n=210528952589;
    mpz_class n("4509540007616669");
    mpz_class p, q;

    metodoFermat(n, p, q);

    std::cout << "p = " << p << std::endl;
    std::cout << "q = " << q << std::endl;

    return 0;
}
