#ifndef IGD
#define IGD


#include <vector>
#include <gmpxx.h> // Use gmpxx.h para utilizar mpz_class
#include <cmath>

using namespace std;

void crivo_mpz(const mpz_class , vector<mpz_class>& );
#endif
