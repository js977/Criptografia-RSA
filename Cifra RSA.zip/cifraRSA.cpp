#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include "CifraRSA.hpp"
#include <sstream>

//ALFABETO	
/* a --------->0
 * b --------->1
 * c --------->2
 * d --------->3
 * e --------->4
 * f --------->5
 * g --------->6
 * h --------->7
 * i --------->8
 * j --------->9
 * k --------->10
 * l --------->11
 * m --------->12
 * n --------->13
 * o --------->14
 * p --------->15
 * q --------->16
 * r --------->17
 * s --------->18
 * t --------->19
 * u --------->20
 * v --------->21
 * w --------->22
 * x --------->23
 * y --------->24
 * z --------->25
 * " " ------->26
 */

using namespace std;

int conversaoDS_LN(char c){//converte letras ---> numeros
	return c - 'a';
}

char conversaoDS_NL(int num) {
        return 'a' + num; // Adiciona o número ao caractere 'a'

}

bool ePrimo(int n,int b){//verifica se n e b são primos
	//Inicializar os valores
	int  n0=n;
	int t0=0;
	int t=1;
	int q=n0/b;
	int r=n0-q*b;
	int temp;
	
	while(r > 0){
		temp=t0 -q*t;
		if (temp >=0)
			temp=temp%n;
		else
			temp=n-((-temp)%n);
		
	//Atualização dos valores
	t0=t;
	t=temp;
	n0=b;
	b=r;
	q=n0/b;
	r=n0-q*b;
}
	if(b==1)
		return 1;
	else
		return 0;
	
}

int inversoMultiplicativo(int n,int b){//calcula o inverso multiplicativo de b mod n
	//inicializar os valores
	int  n0=n;
	int t0=0;
	int t=1;
	int q=n0/b;
	int r=n0-q*b;
	int temp;
	
	while(r > 0){
		temp=t0 -q*t;
		if (temp >=0)
			temp=temp%n;
		else
			temp=n-((-temp)%n);
		
	//Atualização dos valores
	t0=t;
	t=temp;
	n0=b;
	b=r;
	q=n0/b;
	r=n0-q*b;
}
	if(b==1)
		return t;
	else
		return 0;
	
}

int* gerarChavePublica(int q,int p){
	 
	int* chaveP = (int*)malloc(2 * sizeof(int)); // Aloca dinamicamente um array de 2 inteiros
    int omega_n=(p-1)*(q-1);
    if (chaveP == NULL) {
        // Se a alocação falhar
        return NULL;
    }
	//chaveP[1]=(p-1)*(q-1);
	chaveP[1]=p*q;
	//calcular e -->pequeno para melhorar a encriptação
	for(int i=2;i<omega_n;i++){
		
		if(ePrimo(i,omega_n)){
			chaveP[0]=i;
			break;
		}
		}
		return chaveP;
	}
int* gerarChavePrivada(int p, int q,int e){
	// Aloca dinamicamente um array de 2 inteiros
		int* chaveP = (int*)malloc(2 * sizeof(int)); 
    
    if (chaveP == NULL) {
        // Se a alocação falhar
        return NULL;
    }
	chaveP[0]=inversoMultiplicativo((p-1)*(q-1),e);
	chaveP[1]=p*q;
	return chaveP;
}
// Função para calcular (base^exponent) % modulus 
int powerMod(int base, int exp, int mod) {
													
    int res = 1;
    base = base % mod;
// Reduz a base para um valor dentro do módulo 
    while (exp > 0) {
        if (exp % 2 == 1) {
			// Multiplica o resultado pelo valor atual da base e faz o módulo em relação a modulus
			
            res = (res * base) % mod;
        }

        exp = exp/2 ;
        base = (base * base) % mod;
    }

    return res;
}

int cifraEncriptar(int e, int omega_n, int msg) {
    int res = powerMod(msg, e, omega_n);
    return res;
}


int cifraDesencriptar(int d, int omega_n, int c) {
    int res = powerMod(c, d, omega_n);
    return res;
}


void encriptar(int e,int n,fstream& fin,fstream& fout){
int i=0,aux;
string linha;
string nomeMsg;
	while (getline(fin, linha)) {//Obter as linhas do ficheiros
		  while(linha[i]!='\0'){
			aux=conversaoDS_LN(linha[i]);//converter as letras da linha em numeros
			aux=cifraEncriptar(e,n,aux);//Aplicação de encriptação
			i+=1;
			if(aux > n){
				aux=aux%(n);}
			fout <<aux<<" ";}
		fout << endl;
		i=0;}
fout.close();//fechar ambos os ficheiros
fin.close();}


void desencriptar(int d,int n,fstream& fin,fstream& fout){
	int i=0,aux;
	string nomeMsg;
	string linha;
        while (getline(fin, linha)) {//Obter as linhas do ficheiros
			  istringstream linhaAux(linha);
			  while(linhaAux >> aux){
				aux=cifraEncriptar(d,n,aux);//Aplicação de encriptação
				i+=1;
				if(aux > (n)){
					aux=aux%(n);
				}
				fout << conversaoDS_NL(aux);
			}
			fout << endl;
			i=0;
        }
        fin.close();//fechar ambos os ficheiros
        fout.close();
}
