#include <iostream>
#include <cmath>
//#include "CifraRSA.hpp"
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

int main(){
encriptar(2,13);
desencriptar(2,13);
    return 0;
}

