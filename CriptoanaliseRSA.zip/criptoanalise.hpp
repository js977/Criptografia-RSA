#ifndef IGD
#define IGD


using namespace std;

void crivo(unsigned long long int  , unsigned long long int *);
unsigned long long int  metodoDivisao(unsigned long long int  );
unsigned long long int  metodoEuclides(unsigned long long int  );
unsigned long long int  mdc(unsigned long long int  ,unsigned long long int  );
unsigned long long int* metodoFermat(unsigned long long int );
#endif
