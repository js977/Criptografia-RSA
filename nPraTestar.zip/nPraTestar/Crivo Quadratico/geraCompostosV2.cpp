#include <iostream>
#include <gmpxx.h>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

// Função para inicializar o estado do gerador de números aleatórios GMP
gmp_randclass rng(gmp_randinit_default);

// Função para gerar um número primo aleatório com num_digits dígitos
mpz_class random_prime(int num_digits) {
    mpz_class prime_candidate;
    mpz_class min_val;
    mpz_class max_val;
    mpz_class range;

    mpz_ui_pow_ui(min_val.get_mpz_t(), 10, num_digits - 1); // 10^(num_digits - 1)
    max_val = min_val * 10 - 1; // 10^num_digits - 1
    range = max_val - min_val;

    while (true) {
        // Gerar um número aleatório dentro do intervalo [min_val, max_val]
        prime_candidate = min_val + rng.get_z_range(range + 1);

        // Verificar a primalidade do candidato
        if (mpz_probab_prime_p(prime_candidate.get_mpz_t(), 25) > 0) {
            return prime_candidate;
        }
    }
}

int main() {
    // Inicializando o gerador de números aleatórios com a seed
    rng.seed(time(0));

    // Vetor para armazenar os números compostos gerados
    std::vector<mpz_class> composite_numbers;
	int p_digits = 3,q_digits;
    while (composite_numbers.size() < 15) {
        mpz_class p;
         // Começa com 3 dígitos para p
        do {
            p = random_prime(p_digits);
            p_digits++;
        } while (p.get_str().length() < 3); // Garantir que p tenha pelo menos 3 dígitos

        // Agora procuramos um q tal que p * q tenha 23 dígitos
        mpz_class q;
        q_digits = 23 - p.get_str().length(); // Para que p * q tenha 23 dígitos
        q = random_prime(q_digits);

        mpz_class n = p * q;

        // Adicionar ao vetor se tiver exatamente 23 dígitos e ainda não estiver presente
        if (n.get_str().length() == 23 && std::find(composite_numbers.begin(), composite_numbers.end(), n) == composite_numbers.end()) {
            cout << n << "    " << p << "   " << q << endl;
            composite_numbers.push_back(n);
        }
			
    }

    return 0;
}

