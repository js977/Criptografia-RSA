// Biblioteca Standard C++
#include <iostream>
#include <cmath>
#include <limits>
#include <string>
#include <cstdlib>
#include <time.h>
#include <fstream> // necessário para lidar com os ficheiros
#include <chrono>

// Biblioteca GMP
#include <gmp.h>
#include <gmpxx.h> 
#include <mpfr.h>

// Biblioteca do Projecto
#include "cq.hpp"

using namespace std;
using namespace std::chrono;
int main(int argc, char** argv) {
	
	string num,ficheiroNome;
	vector<mpz_class> dados(6);

	if (argc < 3) {
	cout << "Número de argumentos insuficiente\n\n";
	cout << "Utilização: ./crivoquadratico <n> <nome_ficheiro> \n\n";
	cout << "Por exemplo: ./crivoquadratico <n> listaPrimos.csv\n\n";
	return 1; // código de erro - Número de argumentos insuficiente
		}

	ofstream ficheiro(argv[2], ofstream::out);

    if (!ficheiro) {
        cout << "Impossivel abrir o ficheiro " << argv[1] << "\n\n";
        return 2; // Código de erro, não é possível abrir o ficheiro para escrita
    }
	
    num = argv[1];
    ficheiroNome = argv[2];

    mpz_class n(num);
    mpz_class p,q;
    
    crivoQuadratico(n,p,q,dados);
    mpf_class total(dados[3]), t0(dados[0]), t1(dados[1]), t2(dados[2]);

    //cout << tempo[0] << " (" << (t0 / total) * 100 << "%)  "
      //   << tempo[1] << " (" << (t1 / total) * 100 << "%)  "
       //  << tempo[2] << " (" << (t2 / total) * 100 << "%)  "
       //  << tempo[3] << " (" << (total / total) * 100 << "%)" << endl;
    ficheiro << n << " ; " << p << " ; " << q << " ; "<< dados[0] << " (" << (t0 / total) * 100 << "%)  "
         << dados[1] << " (" << (t1 / total) * 100 << "%)  "
         << dados[2] << " (" << (t2 / total) * 100 << "%)  "
         << dados[3] << " (" << (total / total) * 100 << "%)" <<"   "<<dados[4]<<"  "<<dados[5]<<endl;; // não muda de linha (vai continuar a escrever
    ficheiro.close(); // fecha o ficheiro;
}
/*
int main() {
    mpz_class y;
    mpfr_t i;
    mpz_class n(1048576);
    clock_t start, end;
    mpz_class B;

    mpfr_init2(i, 256); // inicializa i com precisão de 256 bits
    mpfr_set_ui(i, 1048576, MPFR_RNDN); // Define i como 2

    // Calcula valorB para os próximos 9 milhões de números
    for (size_t count = 20; count < 9000000; count++) {
        start = clock();
         B =valorB(i);
		 baseFatorial(B,n);
        end = clock();
        // Calcula o tempo em minutos
        double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC / 60;

        // Multiplica i por 2 para o próximo número
        mpfr_mul_ui(i, i, 2, MPFR_RNDN);
        // Converte i para string para impressão
        printf("count = %d, y = %s, Tempo: %f minutos\n", count, y.get_str().c_str(), time_taken);
        // Adiciona uma condição de parada para evitar que o programa rode infinitamente
        if (count % 100000 == 0) {
            cout << "Processed " << count << " iterations." << endl;
        }
    }

    mpfr_clear(i); // Libera a memória alocada para i

    return 0;
}
*/
